<?php

/******************************
* data processing
******************************/

// this function saves the data
function hb_save_data() {
	// save data here
}